Hello,

This is the readme for the source files for the True (Hair) Colors mod for Conan Exiles, Enhanced version.

DESCRIPTION OF CONTENTS

Within are several small data tables containing various color entries, as well as a ModController for performing the relevant data table mergers. There are four older generations of hair colors in the ColorWorkshop folder made during the development of this mod, though for various rejected for the final version. The main table should be front-and-center. The cover image is also included which you can choose to use or not.

There is also an unused folder for brow colors, which can be enabled by linking the proper block in the ModController's Data Table Operations section. I found that brows don't reflect their chosen color very well, with similar colors often becoming indistinguishable, but feel free to try if you want.

INSTALLATION

To add the mod into your DevKit, copy the 'TrueHairColorsEnhanced' folder into the mod directory. From the main DevKit folder, the path will very likely be:

\CEUE5Devkit\UE4\Content\Mods

The mod should only need to be re-cooked (rebuilt) in the DevKit to become functional once again, unless Inflexion, Funcom, or whoever else decide to do some major renovations.

MISCELLANEOUS

If you're interested in testing the mod in advance of publishing or simply for your own use, you can copy the cooked pak file to the Mods folder in your game files and then enable in the main menu.

The pak file uses the name of the RealignedFemaleHair folder in the DevKit and not the mod name in the DevKit's Info Panel. To change the name of the pak (if you want), you can copy the contents of the folder to one with the new name, though you'd have to fix broken references in the ModController's Data Table Operations section.

CONCLUSION

Hopefully that covers the basics, I look forward to seeing your version (as long as you don't mess it up)! If you're the first to re-upload, let me know and I'll provide a link to your mod page.

Thanks for reading,

Dread Swoop